<?php

$CONFIG['title'] = "BARRAS";
$CONFIG['db_name']="examen";
$CONFIG['db_user']="examen";
$CONFIG['db_pass']="examen";
$CONFIG['db_host']="localhost";
$CONFIG['secreto']="B49wQ17B";
$CONFIG['LONG_TOKEN']=64

?>