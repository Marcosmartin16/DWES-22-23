<div class="menu">
  <a href="index.php">Inicio</a>
  <a href="admin.php">Admin</a>
  <a href="privado.php">Privado</a>
  <a href="login.php">Login</a>
  <a href="logout.php">Logout</a>
</div>
